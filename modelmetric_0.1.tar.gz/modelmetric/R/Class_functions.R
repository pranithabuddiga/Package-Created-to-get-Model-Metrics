#' finding model metrics
#'
#' This takes in the predicted and actual values.
#'
#' @name nummetrics
#' @param a,m are the actual and predicted values
#' @return vector of model metrics
#' @export

nummetrics = function(a,m)
{
  metrics= c(MAD=0,MSE=0,MAPE=0,MPSE=0,tMAD=0,P90=0,R2=0)

  metrics["MAD"] <- mean(abs(a-m))
  metrics["MSE"] <- mean((a-m)^2)
  metrics["MAPE"]<- mean(abs((a-m)/a))
  metrics["MPSE"] <- mean(((a-m)/a)^2)
  metrics["tMAD"] <- mean(abs(a-m),trim=0.05)
  metrics["P90"]<- quantile(abs(a-m),probs =0.9)
  SSE<-sum((a-m)^2)
  SST<-sum((a-mean(a))^2)

  metrics["R2"]<- 1-(SSE/SST)

  return(metrics)
}

#' finding model metrics
#'
#' This takes in actual,predicted and no of predictors value
#'
#' @name binmetrics
#' @param a=actual m=model values k=10 sets a default value and can be changed
#' @return returns a vector of binary prediction model metrics
#' @export

binmetrics =function(a,m,k=10)
{

  metrics= c(LL=0,AIC=0,BIC=0,R2=0)

  metrics["LL"]= sum(ifelse(a==1,log(m),log(1-m)))
  metrics["AIC"]= -2*metrics["LL"]+2*k
  n=length(a)
  metrics["BIC"]= -2*metrics["LL"]+2*k*log(n)
  SSE<-sum((a-m)^2)
  SST<-sum((a-mean(a))^2)

  metrics["R2"]<- 1-(SSE/SST)
  return(metrics)
}

